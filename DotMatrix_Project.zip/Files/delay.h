#include "types.h"

// Declaring delay functions
void delay_us(f32 dlyUS);
void delay_ms(f32 dlyMS);
void delay_s(f32 dlyS);
