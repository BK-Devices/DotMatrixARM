#include "types.h"

void initDOTMAT(u32 anode, u32 shift);
void SIPO_74LS164(u8 data, u8 mat);
void charDOTMAT(u8 ch, u8 mat, s32 dly);
void strDOTMAT(u8 *str, s32 dly);
void scrollDOTMAT(u8 *str, s32 dly);

